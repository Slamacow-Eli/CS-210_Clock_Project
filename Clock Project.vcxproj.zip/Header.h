/*
 * Clock Project
 *
 *  Date: [September 20, 2022]
 *  Author: [Elijah Herbert]
 *  Professor: [Michael Rissover]
 *  Class: [CS-210]
 */
